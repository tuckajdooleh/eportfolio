from tkinter import *
import pickle
from PIL import Image, ImageTk

from pathfinding.core.diagonal_movement import DiagonalMovement
from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder


class Window(Frame):

    def __init__(self, master=None):
        Frame.__init__(self, master)

        self.master = master

        self.init_window()

    def init_window(self):

        self.master.title("Pathfinder")
        self.pack(fill=BOTH, expand=1)

        # quitButton = Button(self,text="quit",command=self.client_exit)
        # quitButton.place(x=0,y=0)

        menu = Menu(self.master)
        self.master.config(menu=menu)

        file = Menu(menu)

        menu.add_command(label="Exit", command=self.client_exit)

        menu.add_command(label="Save", command=self.client_save)
        menu.add_command(label="Dev", command=self.dev)
        menu.add_command(label="Path", command=self.path)
        menu.add_command(label="Clear", command=self.clear)

        # menu.add_cascade(label='File',menu =file)

    def client_exit(self):
        exit()

    def clear(self):
        image = canvas.create_image(0, 0, anchor=NW, image=background_image)

    def dev(self):
        changemode()
    def path(self):
        aStar(matrix)

    def client_save(self):
        if mode == -1:

            with open('outfile', 'wb') as fp:
                pickle.dump(matrix, fp)

global mode
mode = 1
rows = 118
cols = 94
matrix = []
begin = [0,0]
stop =[1,1]
currentlength =0

for row in range(cols): matrix += [[0] * rows]

with open ('outfile', 'rb') as fp:
    matrix = pickle.load(fp)

def changemode():
   global mode
   mode*=-1
   if mode == -1:
       for numx in range(cols):
           for numy in range(rows):
               drawsquares(numx, numy, matrix[numx][numy])
   else:

       image = canvas.create_image(0, 0, anchor=NW, image=background_image)



def leftclick(event):
    x, y = event.x, event.y
    x = float(x)
    x = x / 8.4
    x = int(x)
    y = float(y)
    y = y / 8.4
    y = int(y)



    if mode == -1:
        matrix[y][x] = 1
        canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="blue",
                                outline="red")
    else:
        if matrix[y][x] != 1:
            begin[0] = x
            begin[1] = y
            canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="green",
                                    outline="green")

def leftclickmotion(event):
    x, y = event.x, event.y
    x = float(x)
    x = x / 8.4
    x = int(x)
    y = float(y)
    y = y / 8.4
    y = int(y)



    if mode == -1:
        matrix[y][x] = 1
        canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="blue",
                                outline="red")




def rightclick(event):
    x, y = event.x, event.y
    x = float(x)
    x = x / 8.4
    x = int(x)
    y = float(y)
    y = y / 8.4
    y = int(y)
    if mode == 1:
        if matrix[y][x] != 1:
            stop[0] = x
            stop[1] = y
            canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="blue",
                                    outline="blue")
    else:
        matrix[y][x] = 0
        canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="red",
                                outline="red")

def rightclickmotion(event):
    x, y = event.x, event.y
    x = float(x)
    x = x / 8.4
    x = int(x)
    y = float(y)
    y = y / 8.4
    y = int(y)
    if mode == -1:
        matrix[y][x] = 0
        canvas.create_rectangle(x * 8.4, y * 8.4, (x * 8.4) + 8.4, (y * 8.4) + 8.4, fill="red",
                                outline="red")



def drawsquares(indexy, indexx, state):

    if state == 0:
        canvas.create_line(indexx * 8.4, indexy * 8.4, indexx * 8.4, (indexy * 8.4) + 8.4, fill="red")
        canvas.create_line(indexx * 8.4, indexy * 8.4, (indexx * 8.4) + 8.4, (indexy * 8.4), fill="red")
        canvas.create_line((indexx * 8.4) + 8.4, indexy * 8.4, (indexx * 8.4) + 8.4, (indexy * 8.4) + 8.4, fill="red")
        canvas.create_line(indexx * 8.4, (indexy * 8.4) + 8.4, (indexx * 8.4) + 8.4, (indexy * 8.4) + 8.4, fill="red")
    elif state == 'p':
        canvas.create_rectangle(indexx * 8.4 , indexy * 8.4,(indexx * 8.4)+ 8.4,(indexy * 8.4)+ 8.4, fill="black", outline="red")
    # canvas.create_line(42, 13, 126, 13, fill="red")
    elif state == 1:
        canvas.create_rectangle(indexx * 8.4, indexy * 8.4, (indexx * 8.4) + 8.4, (indexy * 8.4) + 8.4, fill="blue",
                                outline="red")





def aStar(matrix):
    # matrix = [
    #  [0, 0, 0, 0, 0, 0],
    #  [1, 1, 1, 1, 1, 0],
    #  [1, 1, 0, 0, 0, 1],
    #  [1, 1, 0, 1, 1, 1],
    #  [1, 1, 0, 0, 0, 1],
    #  [1, 0, 0, 1, 0, 0]
    # ]


   # for i in rows:
   #     for e in cols:
   #         results[i][e] = matrix[e][i]

    grid = Grid(matrix=matrix)


    start = grid.node(begin[0], begin[1])
    end = grid.node(stop[0], stop[1])

    finder = AStarFinder(diagonal_movement=DiagonalMovement.always)
    path, runs = finder.find_path(start, end, grid)

    #print('operations:', runs, 'path length:', len(path))
    #print(grid.grid_str(path=path, start=start, end=end))


    currentlength = (len(path))*20
    #for cord in path:

    #    canvas.create_rectangle(cord[0] * 8.4, cord[1]  * 8.4, (cord[0] * 8.4) + 8.4, (cord[1] * 8.4) + 8.4, fill="black",
    #                        outline="red")
    for i in range(len(path)-1):
        canvas.create_line((path[i][0])*8.4, (path[i][1])*8.4
                           , (path[i+1][0])*8.4, (path[i+1][1])*8.4,
                           fill="red", width = 5)

    canvas.create_rectangle(835, 5, 1000, 65, fill="white",
                            outline="black")

    canvas.create_text(900, 20, fill="orange", font="Times 20 italic bold",
                            text="{} Feet".format(currentlength))
    seconds = currentlength / 4.5
    minutes = int(seconds/60)
    seconds = int(seconds - (minutes*60))
    canvas.create_text(920, 50, fill="orange", font="Times 20 italic bold",
                       text="{}:{} Minutes".format(minutes, seconds))



root = Tk()
root.geometry("1000x1000")

root.bind('<B1-Motion>', leftclickmotion)
root.bind('<Button-1>', leftclick)
root.bind('<B3-Motion>', rightclickmotion)
root.bind('<Button-3>', rightclick)
#root.bind("<KeyPress-s>", on_key_press_repeat)

canvas = Canvas(root, width=1000, height=1000)
background_image = PhotoImage(file="pic.png")
image = canvas.create_image(0, 0, anchor=NW, image=background_image)

canvas.pack()
app = Window(root)

root.mainloop()
